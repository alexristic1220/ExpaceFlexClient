import React from 'react';

function Heading({ meta }) {
    return (
        <React.Fragment>
            <h1>{meta.title}</h1>
            <p>{meta.description}</p>
        </React.Fragment>
    )
}

export default Heading;