import React, { useContext } from "react";
import { AppDataContext } from "../../App";
import ComImg from "../../assets/images/com.svg";
import TimerIcon from "../../assets/images/timer.svg";
import CheckedImg from "../../assets/images/checked.svg";
import BannerImg from "../../assets/images/banner.svg";


const SuccessPayment = () => {
    const { setAppData }: any = useContext(AppDataContext);
    const onBack = () => {
        setAppData({ step: 1 });
    }

    return (
        <React.Fragment>
            <div className="suc-payment">
                <h1>Your payment is successful!</h1>
                <p style={{height:'52px', marginTop:'6px', color:'#3F3F46', fontWeight:'10'}}> Congratulations, your workspace is booked. We sent booking information to your email. <span style={{fontWeight:'500'}}>Thank you for choosing us!</span></p>
                <img src={CheckedImg} alt="checkimg" />
            </div>

            <div className="success-pay-item "  style={{position:'relative', zIndex:'0'}}>
                <img src={BannerImg} alt="" style={{position:'absolute', bottom:'0', left:'0', right:'0', zIndex:'-1', width:'100%', borderRadius:'16px' }}/>
                <div className="first-title">
                    <p>Payment Details</p>
                </div>
                <div className="input-first">
                    <div className="your-name">
                        <span>Selected Type:</span>
                        <button className="btn"><img className="btnimage" src={ComImg} alt="com" /><span>Personal Desk</span></button>
                    </div>
                    <div className="your-name">
                        <span>Total Hours:</span>
                        <button className="btn" > <img className="btntimerimage" src={TimerIcon} alt="timer" /> <span>4 Hours</span></button>
                    </div>
                    <div className="your-name">
                        <span>Date:</span>
                        <span>6th of December, Friday</span>
                    </div>
                    <div className="your-name">
                        <span>Booked Hours:</span>
                        <span>10am-2pm</span>
                    </div>
                </div>
                <div className="input-second">
                    <div className="your-name">
                        <span>Amount Paid</span>
                        <span className="yournamespan">$16</span>
                    </div>
                </div>
            </div>
            <div className="actions" >
                <button className="btn btn-primary btnbackmain finish-moblie-btn"  onClick={onBack} > Back to Main Menu </button>
            </div>
        </React.Fragment >
    )
}

export default SuccessPayment;