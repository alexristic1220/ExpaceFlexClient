import React, { useContext, useState } from "react";
import { AppDataContext } from "../../App";
import MyBookingCalendar from "../bookingcalendar/MyBookingCalendar";
import Image1 from "../../assets/images/room1.png";
import Image2 from "../../assets/images/room2.png";
import Image3 from "../../assets/images/room3.png";
import CarouselNext from "../../assets/images/carousel-next.svg";
import CarouselPrevious from "../../assets/images/carousel-previous.svg";
import { Carousel } from 'react-responsive-carousel';
import { DatePicker } from "@mui/x-date-pickers";
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import "../../assets/css/react-datepicker.css";
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DateCalendar } from '@mui/x-date-pickers/DateCalendar';
import "../../assets/css/slider.css";
import "../../assets/css/personal-details.css";
import MyBookingCalendarResponse from "components/bookingcalendar/MyBookingCalendarResponse";
import dayjs from 'dayjs';

const ScheduleTime = () => {
    const { setAppData, appData }: any = useContext(AppDataContext);
    const onBack = () => {
        setAppData({ ...appData, step: 1 });
    }
    const onNext = () => {
        setAppData({ ...appData, step: 3 });
    }
    const today = new Date();
    const [startDate, setStartDate] = useState(today);
    const [calDate, setCalDate] = useState(new Date());

  

    return (
        <React.Fragment>
            <h1>Schedule time </h1>
            <p> Please select a date and time, that fits you the best.</p>
            <div className="booking-widget" >
                <div className="month-item" >
                    <LocalizationProvider dateAdapter={AdapterDayjs} >
                        <DateCalendar slotProps={{
                            day: {
                                sx: {
                                    ['&[data-mui-date="true"] .Mui-selected']: {
                                        // Reset the background color of the selected date
                                        backgroundColor: '#ED7343',
                                    },
                                    ':not(.Mui-selected)': {
                                        backgroundColor: '#fff',
                                        borderColor: '#ED7343',
                                    },
                                    '&.Mui-selected': {
                                        color: '#fff',
                                        backgroundColor: '#ED7343',
                                        borderColor: '#ED7343',
                                        ':hover, :focus': {
                                            color: '#fff',
                                            backgroundColor: '#ED7343',
                                            borderColor: '#ED7343',
                                        },
                                    },
                                    ':hover': {
                                        color: '#fff',
                                        backgroundColor: '#ED7343',
                                        borderColor: '#ED7343',
                                    },
                                },
                            },
                        }}
                            onChange={(e) => setCalDate(e.$d)}
                        />
                    </LocalizationProvider>
                    <div className="gallery" >
                        <Carousel showThumbs={false} renderArrowPrev={(clickHandler, hasPrev) =>
                            hasPrev && (
                                <div className="carousel-next-slider-prev-button" onClick={clickHandler}>
                                    <img src={CarouselPrevious} alt=""/>
                                </div>
                            )
                        } renderArrowNext={(clickHandler, hasNext) =>
                            hasNext && (
                                <div className="carousel-next-slider-next-button" onClick={clickHandler}>
                                    <img src={CarouselNext} alt=""/>
                                </div>
                            )
                        }>
                            <div className="item" >
                                <img src={Image1} alt="space" />
                            </div>
                            < div className="item" >
                                <img src={Image2} alt="space" />
                            </div>
                            <div className="item" >
                                <img src={Image3} alt="space" />
                            </div>
                        </Carousel>
                        <div className="info" >
                            <span className="price">Starting at {`$${appData.space.price || 0}/h`}</span>
                            <h2 style={{fontSize:'20px', fontWeight:'500'}}>Cowrking For 1</h2>
                        </div>
                    </div>
                    <div className="footer-item">
                        <span className="price">Total Selected Hours:</span>
                        <span className="hours">4 Hours</span>
                    </div>
                </div>
                <div className="day-item" >
                    {/* <BookingCalendar /> */}
                    <MyBookingCalendar checkdate={calDate} />
                </div>
                <div className="day-mobile-item" >
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DemoContainer components={['MobileDatePicker']}>
                                <DatePicker onChange={(e) => setStartDate(dayjs(e).toDate())} defaultValue={dayjs(today)} />
                        </DemoContainer>
                    </LocalizationProvider>

                    {/* <BookingCalendar /> */}
                    <MyBookingCalendarResponse checkdate={startDate} />
                </div>
            </div>
            <div className="actions" >
                <button className="btn btn-secondary" onClick={onBack} > Back </button>
                <button className="btn btn-primary" onClick={onNext} > Next </button>
            </div>
        </React.Fragment>
    )
}

export default ScheduleTime;