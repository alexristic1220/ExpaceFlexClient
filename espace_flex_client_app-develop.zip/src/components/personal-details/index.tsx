import React from 'react';
import Actions from 'components/common/actions';
import Heading from 'components/common/heading';
import CartWidget from './cart-widget';
import PersonalWidget from './personal-widget';
import "../../assets/css/personal-details.css";


interface CartWidgetProps{
    upButton: boolean,
    callback: () => void,
}

const PersonalDetails: React.FC<CartWidgetProps> = (props) => {
    const meta = {
        title: 'Personal Details',
        description: 'Fill in required fields for smooth payment processing. Your information ensures effective communication.'
    }

    return (
        <React.Fragment>
            <Heading meta={meta} />
            <div className="personal-details">
                <PersonalWidget />
                <CartWidget upButton={props.upButton} callback={props.callback} />
            </div>
            <Actions />
        </React.Fragment>
    )
}

export default PersonalDetails;