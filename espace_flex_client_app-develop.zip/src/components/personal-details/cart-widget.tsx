import React from 'react';
import ComputerIcon from "../../assets/images/com.svg";
import TimerIcon from "../../assets/images/timer.svg";
import ArrowUp from "../../assets/images/arrowup.svg";
import ArrowDown from "../../assets/images/arrowdown.svg";
import { IconButton } from '@mui/material';
import BannerImg from "../../assets/images/banner-phone.png";

interface CartWidgetProps{
    upButton: boolean,
    callback: () => void,
}
const CartWidget:React.FC<CartWidgetProps> = (props) => {
    const upButton = props.upButton
    return (
        <>
            <div className="cart-widget show-cart-phone" style={{ height: `${!upButton ? 'max-content' : '258px'}` , position: 'relative', zIndex: '2'}}>
                {
                    upButton &&
                    <img src={BannerImg} alt="" style={{ position: 'absolute', bottom: '0px', left: '0', right: '0', zIndex: '-1', width: '100%', borderRadius: '16px', overflow: 'revert-layer' }} />

                }
                <div style={{ display: 'flex', flexDirection: 'row', width: '100%', position: 'relative', flexFlow: 'row' }}>
                    <h3>Your Cart</h3>
                    <IconButton onClick={() => props.callback()} className='response-button' style={{ position: 'absolute' }}>
                        <img className="" src={upButton === true ? ArrowUp : ArrowDown} alt="timer" />
                    </IconButton>
                </div>
                {upButton &&
                    <div style={{ gap: '12px' }}>
                        <div className="selected-type">
                            <span>Selected Type:</span>
                            <div className="feature">
                                <img src={ComputerIcon} alt="computer" />
                                <span>Personal Desk</span>
                            </div>
                        </div>
                        <div className="total-hours">
                            <span>Total Hours:</span>
                            <div className="feature">
                                <img src={TimerIcon} alt="timer" />
                                <span>4 Hours</span>
                            </div>
                        </div>
                        <div className="total-price">
                            <span>Total Price:</span>
                            <span className="price">$48</span>
                        </div>
                    </div>
                }
            </div>
            <div className="cart-widget show-cart-desktop" style={{ position: 'relative', zIndex: '2' }}>
                <img src={BannerImg} alt="" style={{ position: 'absolute', bottom: '0px', left: '0', right: '0', zIndex: '-1', width: '100%', borderRadius: '16px', overflow: 'revert-layer' }} />
                <div>
                    <h3>Your Cart</h3>
                </div>
                <div className="selected-type">
                    <span>Selected Type:</span>
                    <div className="feature">
                        <img src={ComputerIcon} alt="computer" />
                        <span>Personal Desk</span>
                    </div>
                </div>
                <div className="total-hours">
                    <span>Total Hours:</span>
                    <div className="feature">
                        <img src={TimerIcon} alt="timer" />
                        <span>4 Hours</span>
                    </div>
                </div>
                <div className="total-price">
                    <span>Total Price:</span>
                    <span className="price">$48</span>
                </div>
            </div>
        </>
    )
}

export default CartWidget;