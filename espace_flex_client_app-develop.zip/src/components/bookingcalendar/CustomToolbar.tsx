import React from "react";

const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export const CustomToolbar: React.FC = () => {
    return (
        <>
            <div style={{display:'flex', flexDirection:'row', paddingLeft:'45px'}}>
                {
                    days.map((item) => (
                        <div style={{ width: '120px', textAlign:'center', fontWeight:'400', color:'#52525B'}}>{item}</div>
                    ))
                }
                
            </div>
        </>
    )
}