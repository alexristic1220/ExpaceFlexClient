'use client'

import React, { useState } from "react";
import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import "../../assets/css/react-big-calendar.css";

const localizer = momentLocalizer(moment);

const MyBookingCalendarResponse = ({ checkdate, ht }: any) => {
    const [bookings, setBookings] = useState<{ start: any; end: any, title: string }[]>(
        [],
    );

    let formats1 = {
        timeGutterFormat: 'h a',
    }

    const handleSelect = ({ start, end }: any) => {
        const title = "Booked";

        if (title)
            setBookings([
                ...bookings,
                {
                    start,
                    end,
                    title
                }
            ]);
    };
    return (

        <div>
            <div style={{marginTop:'12px'}}></div>
            <Calendar
                localizer={localizer}
                events={bookings}
                startAccessor="start"
                endAccessor="end"
                defaultDate={checkdate}
                date={checkdate}
                style={{ border: 0 }}
                defaultView="day"
                timeslots={1}
                step={60}
                dateFormat="h t"
                formats={formats1}
                selectable
                components={{
                    toolbar: 'null',
                    day: {
                        header: ({ date, localizer }) => localizer.format(date, 'ddd'),
                    },
                }}
                min={
                    new Date(
                        checkdate.getFullYear(),
                        checkdate.getMonth(),
                        checkdate.getDate(),
                        8
                    )
                }
                max={
                    new Date(
                        checkdate.getFullYear(),
                        checkdate.getMonth(),
                        checkdate.getDate(),
                        23,50,50
                    )
                }
                onSelectSlot={handleSelect}
            />
        </div>
    );
}
export default MyBookingCalendarResponse
