'use client'

import React, { useState } from "react";
import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import { CustomToolbar } from "./CustomToolbar";
import "../../assets/css/react-big-calendar.css";

const localizer = momentLocalizer(moment);

const MyBookingCalendar = ({ checkdate, ht }: any) => {
    const [bookings, setBookings] = useState<{ start: any; end: any, title: string }[]>(
        [],
    );
  
    let formats1 = {
        timeGutterFormat: 'h a',
    }


    const handleSelect = ({ start, end }: any) => {
        const title = "Booked";
        if (title)
            setBookings([
                ...bookings,
                {
                    start,
                    end,
                    title
                }
            ]);
    };
    return (

        <div>
            <Calendar
                localizer={localizer}
                events={bookings}
                startAccessor="start"
                endAccessor="end"
                defaultDate={checkdate}
                date={checkdate}
                style={{ border: 0 }}
                defaultView="week"
                timeslots={1}
                step={60}
                dateFormat="h t"
                formats={formats1}
                selectable
                components={{
                    toolbar: CustomToolbar,
                    week: {
                        header: ({ date, localizer }) => (localizer.format(date, 'l').toString().split('/')[1]),
                    },
                    // header: ({date}) => moment(date).date,
                }}
                min={
                    new Date(
                        checkdate.getFullYear(),
                        checkdate.getMonth(),
                        checkdate.getDate(),
                        8,
                        0,
                        0
                    )
                }
                max={
                    new Date(
                        checkdate.getFullYear(),
                        checkdate.getMonth(),
                        checkdate.getDate(),
                        23,
                        50,
                        50
                    )
                }
                onSelectSlot={handleSelect}
            />
        </div>
    );
}
export default MyBookingCalendar
