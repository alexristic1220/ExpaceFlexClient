import React from "react";
import SpaceList from "./List";
import { spaces } from "./mock";

function Spaces() {
    return (
        <React.Fragment>
            <h1>Our spaces</h1>
            <p>Please selected a workspace, that fits you the best.</p>
            <SpaceList spaces={spaces} />
        </React.Fragment>
    )
}

export default Spaces;
