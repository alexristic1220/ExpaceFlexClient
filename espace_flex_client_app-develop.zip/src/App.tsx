import React, { useState } from "react";
import PaymentModal from "pages/Payment.Modal";
export const AppDataContext = React.createContext(null);

function App() {

  const [upButton, setUpButton] = useState(false);

  const handlerClick = () => {
      setUpButton(!upButton);
  }
  
  return (
    <PaymentModal upButton={upButton} callback={handlerClick} />
  );
}

export default App;