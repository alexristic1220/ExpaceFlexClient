import React, { useState } from "react";
import "../assets/css/app.css";
import ScheduleTime from "../components/schedule";
import Spaces from "../components/space/Index";
import Payment from "components/schedule/Payment";
import Loading from "components/schedule/Loading";
import CancelSVG from "assets/images/cancel.svg";
import PersonalDetails from "components/personal-details";
import { AppDataContext } from "App";

interface CartWidgetProps{
    upButton: boolean,
    callback: () => void,
}

const PaymentModal:React.FC<CartWidgetProps> = (props) => {
  const [appData, setAppData] = useState({
    step: 1,
    space: null
  })
  const [showModal, setShowModal] = useState('');

    return (
    appData.step < 5 ?
      (<div className="booking-app" style={{ display: `${showModal}` }}>
        {appData.step === 1 && (<div><span className="step">{appData.step}/4</span><button className="cancelbtn" onClick={() => setShowModal('none')}><img src={CancelSVG} alt="cancelimg"></img></button></div>)}
        {appData.step === 2 && (<div><span className="step">{appData.step}/4</span><button className="cancelbtn" onClick={() => setShowModal('none')}><img src={CancelSVG} alt="cancelimg"></img></button></div>)}
        {appData.step === 3 && (<div><span className="step">{appData.step}/4</span><button className="cancelbtn" onClick={() => setShowModal('none')}><img src={CancelSVG} alt="cancelimg"></img></button></div>)}
        {appData.step === 4 && (<div><span className="step">{appData.step}/4</span><button className="cancelbtn" onClick={() => setShowModal('none')}><img src={CancelSVG} alt="cancelimg"></img></button></div>)}
        <AppDataContext.Provider value={{ appData, setAppData }}>
          {
            appData.step === 1 && <Spaces />
          }
          {
            appData.step === 2 && <ScheduleTime />
          }
          {
            appData.step === 3 && <PersonalDetails upButton={props.upButton} callback={props.callback}/>
          }
          {
            appData.step === 4 && <Payment />
          }

        </AppDataContext.Provider>
      </div>) : (<div className="booking-loading-app">
        <AppDataContext.Provider value={{ appData, setAppData }}>
          <Loading items={appData.space} />
        </AppDataContext.Provider>
      </div>)
  );
}

export default PaymentModal;